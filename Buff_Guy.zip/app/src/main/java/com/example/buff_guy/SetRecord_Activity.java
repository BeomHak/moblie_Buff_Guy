package com.example.buff_guy;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class SetRecord_Activity  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setgoal);


        CheckBox chkBox001 = findViewById(R.id.checkBox001);
        CheckBox chkBox002 = findViewById(R.id.checkBox002);
        CheckBox chkBox003 = findViewById(R.id.checkBox003);
        CheckBox chkBox004 = findViewById(R.id.checkBox004);
        CheckBox chkBox005 = findViewById(R.id.checkBox005);
        CheckBox chkBox006 = findViewById(R.id.checkBox006);
        CheckBox chkBox007 = findViewById(R.id.checkBox007);
        CheckBox chkBox008 = findViewById(R.id.checkBox008);

        CheckBox chkBox101 = findViewById(R.id.checkBox101);
        CheckBox chkBox102 = findViewById(R.id.checkBox102);
        CheckBox chkBox103 = findViewById(R.id.checkBox103);
        CheckBox chkBox104 = findViewById(R.id.checkBox104);
        CheckBox chkBox105 = findViewById(R.id.checkBox105);
        CheckBox chkBox106 = findViewById(R.id.checkBox106);
        CheckBox chkBox107 = findViewById(R.id.checkBox107);
        CheckBox chkBox108 = findViewById(R.id.checkBox108);

        Button backBtn = findViewById(R.id.BackBtn);
        Button OKBtn = findViewById(R.id.OKBtn);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        OKBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SaveGoal();
                finish();
            }
        });
    }

    public void SaveGoal(){
        //체크박스 항목을 찾아서 DB에 저장하는 함수
    }


}
