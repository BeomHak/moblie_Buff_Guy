package com.example.buff_guy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Home_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_);

        TextView ExCount = findViewById(R.id.CountNumView);
        TextView KcalCount = findViewById(R.id.KcalNumView);
        TextView TimeCount = findViewById(R.id.MinNumView);
        Button GoalBtn = findViewById(R.id.GoalBtn);
        Button GoBtn1 = findViewById(R.id.GoBtn1);
        Button GoBtn2 = findViewById(R.id.GoBtn2);
        Button ChkRec = findViewById(R.id.RecordChk);


        setRecords();

        GoalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SetRecord_Activity.class);
                startActivity(intent);
            }
        });
        // 목표설정 버튼

        GoBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Exercise_Activity.class);
                startActivity(intent);
                //추후에는 데이터도 넘겨라
            }
        });
        //운동하기 버튼 1

        GoBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Exercise_Activity.class);
                startActivity(intent);
                //추후에는 데이터도 넘겨라
            }
        });
        //운동하기 버튼2

        ChkRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Record_Activity.class);
                startActivity(intent);
                //추후에는 데이터도 넘겨라
            }
        });

    }

    public void setRecords(){
        //db에서 데이터를 불러온 후
        //setText로 숫자 변경
    }
}
