package com.example.buff_guy;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Login_Activity extends AppCompatActivity {

 //
  //


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);

        Button Login_btn = (Button)findViewById(R.id.LoginBtn);
        TextView findPwView = findViewById(R.id.FindPwView);
        TextView findIdView =  findViewById(R.id.FindIDView);
        TextView signup =findViewById(R.id.SignUpView);
        final EditText id = findViewById(R.id.IDedt);
        final EditText pw =findViewById(R.id.PWedt);


        Login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input_id = id.getText().toString();
                String input_pw = pw.getText().toString();

                Log.i("asdf",input_id + input_pw);

                if(input_id.equals("asdf")  && input_pw.equals("asdf")){
                    Intent intent = new Intent(getApplicationContext(), Home_Activity.class);
                    startActivity(intent);
                }
                else{

                    Toast.makeText(getApplicationContext(),"ID , PW를 확인해 주세요.", Toast.LENGTH_LONG).show();
                }
            }
        });
        //로그인 버튼 관련

        findIdView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Login_Activity.this);
                LayoutInflater inflater = getLayoutInflater();
                View layout = inflater.inflate(R.layout.find_pw,null);
                builder.setView(layout);
                final EditText findpwedt = (EditText)layout.findViewById(R.id.FindIDEdt);

                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(findpwedt.getText().toString().equals("이범학")){
                            Toast.makeText(getApplicationContext(),"아이디는 : asdf.", Toast.LENGTH_LONG).show();
                        }
                    }
                });

                builder.setNegativeButton(android.R.string.cancel, null);

                builder.create().show();

            }
        });
        //아이디 찾기 관련

        findPwView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Login_Activity.this);
                LayoutInflater inflater = getLayoutInflater();
                View layout = inflater.inflate(R.layout.find_pw,null);
                builder.setView(layout);
                final EditText findpwedt = (EditText)layout.findViewById(R.id.FindIDEdt);

                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(findpwedt.getText().toString().equals("asdf")){
                            Toast.makeText(getApplicationContext(),"비밀번호는 : asdf.", Toast.LENGTH_LONG).show();
                        }
                    }
                });

                builder.setNegativeButton(android.R.string.cancel, null);

                builder.create().show();
            }
        });
        //비번 찾기 관련

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SingUp_Activity.class);
                startActivity(intent);
            }
        });


    }


}
